package lab3Q1;

public enum AccountType {
	CHECKING,SAVINGS, RETIREMENT;
}
