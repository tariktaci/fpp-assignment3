package lab3Q4;

public final class Triangle {
	private double height;
	private double base;

	public Triangle(double height, double base) {

		this.height = height;
		this.base = base;
	}

	public Triangle(double side1, double side2, double side3) {
		double b = side1;
		if (b < side2) {
			b = side2;
		}  
		if(b<side3){
			b = side3;
		}
		System.out.println("the base of the three side"+b);
		double s = (side1 + side2 + side3) / 2;
		double areside = Math.sqrt(s * (s - side1) * (s - side2) * (s - side3));
		double h = areside / 0.5 * b;
		this.base = b;
		this.height = h;
	}

	public double computeArea() {
		double areTr = 0.5 * base * height;
		return areTr;
	}

	public double getHeight() {
		return height;
	}

	public double getBase() {
		return base;
	}

}
