package lab3Q2;

public class Employee {

}
